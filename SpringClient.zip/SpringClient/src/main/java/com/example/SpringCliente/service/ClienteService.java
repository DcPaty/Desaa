/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.example.SpringCliente.service;

import com.example.SpringCliente.entity.Cliente;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.SpringCliente.repository.ClienteRepository;


@Service
public class ClienteService {
    @Autowired
    private ClienteRepository repository;

    public List<Cliente> listar() {
        return repository.findAll();
    }
    public Cliente guardar(Cliente cliente) {
        return repository.save(cliente);
    }
    public Cliente obtenerPorId(String id) {
        return repository.findById(id).orElse(null);
    }
    public void eliminar(String id) {
        repository.deleteById(id);
    }
}

