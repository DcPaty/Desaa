/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.example.SpringCliente.controller;

import com.example.SpringCliente.entity.Cliente;
import com.example.SpringCliente.service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

/**
 *
 * @author ESTUDIANTE
 */
@Controller
public class ClienteController {

    @Autowired
    private ClienteService service;

    @GetMapping("/")
    public String listar(Model model) {
        model.addAttribute("clientes", service.listar());
        model.addAttribute("cliente", new Cliente());

        return "clientes";
    }

    @PostMapping("/guardar")
    public String guardar(Cliente cliente) {
        service.guardar(cliente);
        return "redirect:/";
    }
    
    @GetMapping("/editar/{id}")
    public String editar(@PathVariable("id") String id, Model model) {

        Cliente cliente = service.obtenerPorId(id);
        model.addAttribute("cliente", cliente);
        model.addAttribute("clientes", service.listar());
        return "clientes";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable("id") String id) {
        service.eliminar(id);
        return "redirect:/";
    }
}

