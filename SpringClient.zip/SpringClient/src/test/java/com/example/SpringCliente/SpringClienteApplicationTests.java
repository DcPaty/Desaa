package com.example.SpringCliente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringClienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
